"use strict";window.addEventListener("securitypolicyviolation",function(e){var i={},r=["blockedURI","documentURI","effectiveDirective","violatedDirective","originalPolicy","sourceFile","referrer","type"];r.forEach(function(r){i[r]=e[r]}),chrome.runtime.sendMessage(i)});
//# sourceMappingURL=contentscript.js.map
